Reproducibility Instructions (MViTv2 Implementation)

1. Main Execution File
   a. The complete experimental pipeline is implemented in: notebook_MViTv2.ipynb
   b. The notebook was developed and validated in a Kaggle environment.

2. Required Data
   a. Two datasets must be attached to the notebook before execution:
      (1) MViTv2 Code.zip
      (2) Training Dataset.zip >> This zip file consists of several folders and files as follows. 
           Other than (i), all other files and folder can be downloaded from here.
           After downloading all files and folders, store them in ne folder, zip it and create the Training Dataset.
 
	  i)   ISIC_2019_Training_Input (please download from officially public website https://isic-archive.s3.amazonaws.com/challenges/2019/ISIC_2019_Training_Input.zip)
          ii)  data (please download from here)
          iii) ISIC_2019_Training_GroundTruth.csv (please download from here)
          iv)  ISIC_2019_Training_Metadata.csv (please download from here)
          v)   SkinCON.csv  (please download from here)
          vi)  SkinCON_clean.csv  (please download from here)
   
   b. All internal path variables should be updated to match the dataset mounting directories in the execution environment.

3. Running the Experiment
   a. Attach the required datasets.
   b. Verify path configuration in the initialization cell.
   c. Execute the notebook sequentially.

4. Generated Outputs
   a. The METRICS section dynamically generates measure_export.py for metric computation.
   b. The notebook also includes dedicated metric computation blocks.
   c. Users may modify the metric sections according to their reporting requirements.
   d. All outputs are not automatically saved unless explicitly configured by the user.

Notes
a. No external dependencies beyond those specified in the notebook are required.
b. The implementation is fully self-contained within the provided notebook.