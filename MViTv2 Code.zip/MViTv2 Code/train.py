import os
import timm
import time
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import models, transforms
from torch.utils.data import DataLoader

import datasets
from datasets import build_dataset

 
class_num = 8
epoch_num = 30
log_file = 
batch_size = 8

# device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
output_dir = 
data_dir = 

# -----------------------------
# Self-MLP head (classifier)
# -----------------------------
# class SelfMLPHead(nn.Module):
#     def __init__(self, in_features: int, num_classes: int, hidden: int = 512, dropout: float = 0.2):
#         super().__init__()
#         self.net = nn.Sequential(
#             nn.Linear(in_features, hidden),
#             nn.ReLU(inplace=True),
#             nn.Dropout(p=dropout),
#             nn.Linear(hidden, num_classes),
#         )

#     def forward(self, x):
#         return self.net(x)
#-----------------------------
# Define model : ResNet50
#model = models.resnet50(pretrained=True)
#----------------------------------------
# Define model: MViTv2-Tiny+SelfMLP backbone (timm)
#model = timm.create_model("mvitv2_tiny", pretrained=True, num_classes=0)
#-------------------------------------------
# Define model: MViTv2-Tiny backbone  (timm)
model = timm.create_model("mvitv2_tiny", pretrained=True, num_classes=class_num)
#---------------------------------------------

os.makedirs(output_dir, exist_ok=True)

data_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'val': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
}
dataset_train, _ = build_dataset(is_train=True, nb_classes=class_num,dataset_root=data_dir,transform=data_transforms['train'])
dataset_val, _ = build_dataset(is_train=False, nb_classes=class_num,dataset_root=data_dir,transform=data_transforms['val'])
dataloader_train = DataLoader(dataset_train, batch_size=batch_size, shuffle=True)
dataloader_val = DataLoader(dataset_val, batch_size=batch_size, shuffle=False) 
dataloaders = {'train': dataloader_train, 'val': dataloader_val}
dataset_sizes = {'train':len(dataset_train), 'val':len(dataset_val) }

# #Change classifier accordingly for different models
# num_ftrs = model.fc.in_features   # ResNet50
# model.fc = nn.Linear(num_ftrs, class_num)
#-------------------------------------------------------
# Change classifier: ResNet50 + Self-MLP head
# num_ftrs = model.fc.in_features
# model.fc = SelfMLPHead(in_features=num_ftrs, num_classes=class_num, hidden=512, dropout=0.2)
#-------------------------------------------------------

model = model.to(device)

criterion = nn.functional.cross_entropy
criterion_extra = nn.KLDivLoss(reduction="batchmean")
optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

def train_model(model, criterion, optimizer, num_epochs=epoch_num):
    for epoch in range(num_epochs):
        epoch_start = time.time()   # Time Start
        print(f'Epoch {epoch}/{num_epochs - 1}')
        for phase in ['train', 'val']:
            if phase == 'train':
                model.train() 
            else:
                model.eval()

            running_loss = 0.0
            running_corrects = 0

            for batch_num,(inputs,label1, label2) in enumerate(dataloaders[phase]):
                optimizer.zero_grad()
                inputs = inputs.to(device)
                label1 = label1.to(device)
                label2 = label2.to(device)
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    
                    loss = criterion(outputs, label1) + 0.1 * criterion_extra(torch.nn.functional.log_softmax(outputs, dim=1), label2) 

                    if phase == 'train':
                        loss.backward()
                        optimizer.step()
                        # acc=torch.sum(preds == label1.data)/batch_size
                        acc = torch.sum(preds == label1.data) / inputs.size(0)
                        print(f'batch {batch_num}/{len(dataloaders[phase])}, loss: {loss.item()}', f'acc: {acc}', end='\r')
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == label1.data)
                
            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print(f'{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')
            # save weights
            if phase == 'val':

                torch.save(model.state_dict(), os.path.join(output_dir, f'mvitv2t_{epoch}.pth'))
                # ------------------------------------------------------------------------------------
                with open(os.path.join(output_dir, log_file), 'a') as f:
                    f.write(f'epoch: {epoch}, loss: {epoch_loss}, acc: {epoch_acc}\n')
        epoch_time = time.time() - epoch_start  # Total Time for each epoch 
        print(f"Time: {epoch_time:.2f}s")       # Print time for each epoch
train_model(model, criterion, optimizer, num_epochs=epoch_num)